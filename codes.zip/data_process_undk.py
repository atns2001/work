import math
import os
import pickle
import numpy as np
import pandas as pd

data_list = []
data_stamp_list = []

file_folder = '../dataset/NYSE'

# 获取文件夹中所有CSV文件的文件名，并按文件名排序
file_names = sorted([f for f in os.listdir(file_folder) if f.endswith('.csv')])

result_df = pd.DataFrame()

j = 0

# 逐个读取CSV文件
for file_name in file_names:
    print(j)
    j = j + 1
    file_path = os.path.join(file_folder, file_name)
    df_data = pd.read_csv(file_path)

    if len(df_data) < 1000:
        continue

    # 找到close为0的位置
    zero_positions = df_data[df_data['close'] == 0].index
    # 将close为0的位置置为空值
    df_data.loc[zero_positions, 'close'] = np.nan

    df_data = df_data.sort_values(by='date').reset_index(drop=True)
    # 使用前一个的close填充空值的close
    df_data['close'].fillna(method='ffill', inplace=True)

    df_data['pct_chg'] = (df_data['close'].diff() / df_data['close'].shift()) * 100
    df_data.dropna(subset=['pct_chg'], inplace=True)

    df_raw = df_data.loc[:, ['ticker', 'pct_chg', 'date']].copy().reset_index(drop=True)
    
    df_raw['date'] = pd.to_datetime(df_raw.date)

    # 筛选2013年到2022年的数据
    start_date = pd.to_datetime('2018-01-01')
    end_date = pd.to_datetime('2022-12-31')
    df_raw = df_raw[(df_raw['date'] >= start_date) & (df_raw['date'] <= end_date)].reset_index(drop=True)

    if len(df_raw) >= 1000:
        result_df = pd.concat([result_df, df_raw]).reset_index(drop=True)

result_df = result_df.reset_index(drop=True)
print(result_df)

with open('../dataset/NYSE.pkl', 'wb') as f:
    pickle.dump(result_df, f, pickle.HIGHEST_PROTOCOL)
