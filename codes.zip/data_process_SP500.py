import math
import os
import pickle
import numpy as np
import pandas as pd

data_list = []
data_stamp_list = []

file_folder = '../dataset/SP500'

# 获取文件夹中所有CSV文件的文件名，并按文件名排序
file_names = sorted([f for f in os.listdir(file_folder) if f.endswith('.csv')])

result_df = pd.DataFrame()

j = 0

# 逐个读取CSV文件
for file_name in file_names:
    print(j)
    j = j + 1
    file_path = os.path.join(file_folder, file_name)
    df_data = pd.read_csv(file_path)

    df_data['ticker'] = file_name
    df_data = df_data.rename(columns={'Log_Chg': 'pct_chg'})
    df_data = df_data.rename(columns={'Date': 'date'})

    df_data = df_data.sort_values(by='date').reset_index(drop=True)

    df_raw = df_data.loc[:, ['ticker', 'pct_chg', 'date']].copy().reset_index(drop=True)
    
    for i in range(len(df_raw)):
        up = math.floor(float(df_raw.loc[i, 'pct_chg']) / 0.5)
        if up < -70:
            up = -71
        elif up > 69:
            up = 70
        up = up + 71  # -71~-1 0~70 -> 0~141
        if up < 0:
            print("up = " + str(up))
        df_raw.loc[i, 'pct_chg'] = int(up)
    df_raw['date'] = pd.to_datetime(df_raw.date)

    result_df = pd.concat([result_df, df_raw]).reset_index(drop=True)

result_df = result_df.reset_index(drop=True)
print(result_df)

with open('../dataset/SP500_dk.pkl', 'wb') as f:
    pickle.dump(result_df, f, pickle.HIGHEST_PROTOCOL)