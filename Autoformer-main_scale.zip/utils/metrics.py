import numpy as np


def RSE(pred, true):
    return np.sqrt(np.sum((true - pred) ** 2)) / np.sqrt(np.sum((true - true.mean()) ** 2))


def CORR(pred, true):
    u = ((true - true.mean(0)) * (pred - pred.mean(0))).sum(0)
    d = np.sqrt(((true - true.mean(0)) ** 2).sum(0) * ((pred - pred.mean(0)) ** 2).sum(0))
    return (u / d).mean(-1)


def MAE(pred, true):
    return np.mean(np.abs(pred - true))


def MSE(pred, true):
    return np.mean((pred - true) ** 2)


def RMSE(pred, true):
    return np.sqrt(MSE(pred, true))


def MAPE(pred, true):
    return np.mean(np.abs((pred - true) / true))


def MSPE(pred, true):
    return np.mean(np.square((pred - true) / true))

def Plus_Mius(pred, true): 
    count = 0

    # 统计pred中69、70、71和72的数量
    # count = np.sum(np.logical_or.reduce([(pred > -0.1) & (pred < 0.55)]))

    count2 = np.sum(np.logical_or.reduce([(true > -0.1) & (true < 0.55)]))

    # count1 = np.sum(pred == 0)
    # count2 = np.sum(true == 0)

    # 将true中与pred相同位置的值设置为pred的值
    # true_modified = np.where(np.logical_or.reduce([(pred > -0.1) & (pred < 0.5)]), pred, true)
    # true_modified = np.where(pred == 1, pred, true)

    pred_sign = np.where(pred < 0, -1, 1)
    true_sign = np.where(true < 0, -1, 1)
    # # true_sign = np.where(true < 0, -1, 1)
    sign_match = pred_sign == true_sign
    # sign_match = pred == true
    match_count = np.sum(sign_match)

    total_count = pred.size
    percentage = (match_count - count) * 100 / (total_count - count)
    print(count, count2, total_count)
    return percentage


def metric(pred, true):
    mae = MAE(pred, true)
    mse = MSE(pred, true)
    rmse = RMSE(pred, true)
    mape = MAPE(pred, true)
    mspe = MSPE(pred, true)
    per = Plus_Mius(pred, true)

    return mae, mse, rmse, mape, mspe, per
